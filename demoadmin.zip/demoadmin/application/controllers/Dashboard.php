<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Menu_model');
	}

	public function index()
	{
		$isPermission = $this->Menu_model->checkPermission('dashboard');
		if(empty($isPermission))
		{
			redirect(base_url()."permissionerror"); 
		}
		$data['isPermission'] = $isPermission;
		$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
		$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
		$data['all_parent'] = $this->Menu_model->getParentMenu();
		$data['title'] = 'Dashboard';
		$this->load->view('dashboard',$data);
	}
}