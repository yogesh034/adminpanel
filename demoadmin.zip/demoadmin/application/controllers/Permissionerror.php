<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Permissionerror extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();	
	}

	public function index()
	{
		$this->load->model('Menu_model');
		$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
		$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
		$data['title']      = '401';
		$this->load->view('permission-error',$data);
	}
}