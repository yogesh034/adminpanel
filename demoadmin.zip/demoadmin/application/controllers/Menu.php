<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Menu extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		header('Cache-Control: no-cache, must-revalidate, max-age=0');
		header('Cache-Control: post-check=0, pre-check=0',false);
		header('Pragma: no-cache');
		$this->load->model('Menu_model');
	}

	public function add($id='')
	{
		if($this->session->appraisal_logged_in)
		{		
			$isPermission = $this->Menu_model->checkPermission('menu/create');
			if(empty($isPermission))
			{
				redirect(base_url()."permissionerror"); 
			}

			$data['isPermission'] = $isPermission;
			$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
			$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
			$data['all_parent'] = $this->Menu_model->getParentMenu();
			$data['title'] = 'Menu';
			$data['error'] = '';
			$data['menuID'] = $id;
			if($this->input->post())
			{	
				$this->form_validation->set_rules('name', 'Menu Name', 'required',
	            	array('required' => '%s is must be required.'));	            
	            if ($this->form_validation->run() != FALSE){
	            	$check = $this->Menu_model->checkMenu($this->input->post('name'),$id);
	            	if(!$check)
	            	{
	            		if($this->Menu_model->addMenu($this->input->post(),$id))
	            		{	
	            			if($id == '')
	            			{
	            				$this->session->set_flashdata('menu', 'Menu created successfully.');
	            				redirect(base_url()."menu/create"); 
	            			}else{
	            				$this->session->set_flashdata('menu', 'Menu updated successfully.');
	            				redirect(base_url()."menu/view"); 
	            			}	            			
	            		}else{
	            			$data['error'] = var_dump($this->db->error());
	            		}
	            	}else{
	            		$data['error'] = 'Menu name allready exists!';
	            	}         	
	            } 
			}		
			else{
				if($id != '')
				{
					$data['menu_imfo'] = $this->Menu_model->getMenuRow($id);
				}
			}
			$this->load->view('menu/create-menu',$data);
		}else{
			redirect(base_url()."login");
		}
	}

	public function list()
	{
		if($this->session->appraisal_logged_in)
		{		
			$isPermission = $this->Menu_model->checkPermission('menu/view');
			if(empty($isPermission))
			{
				redirect(base_url()."permissionerror"); 
			}
			
			$data['isPermission'] = $isPermission;
			$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
			$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
			$data['all_parent'] = $this->Menu_model->getParentMenu();
			$data['title'] = 'Menu';
			$this->load->view('menu/menu-view',$data);

		}else{
			redirect(base_url()."login");
		}
	}

	public function delete()
	{
		$isdelete = $this->Menu_model->deleteMenu($this->input->post('id'));
		if($isdelete)
		{
			$this->session->set_flashdata('menu', 'Menu deleted successfully.');
			echo 1;
		}else{
			echo var_dump($this->db->error());
		}
	}

	public function userpermission($roll_id='')
	{
		if($this->session->appraisal_logged_in)
		{	
			$isPermission = $this->Menu_model->checkPermission('menu/permission');
			//print_r($isPermission);
			if(empty($isPermission))
			{
				redirect(base_url()."permissionerror"); 
			}

			$data['isPermission'] = $isPermission;
			$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
			$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
			$data['user_roll']  = $this->Menu_model->getRoll();
			if($roll_id != '')
			{
				$data['menu_tree']  = $data['menu_list'];
				$data['menu_group'] = $this->Menu_model->getPermissiondata($roll_id);
			}
			else{
				$data['menu_tree']  = array();
				$data['menu_group'] = array();
			}
			$data['title'] = 'Menu Permission';
			$data['error'] = '';
			$data['roll_id'] = $roll_id;

			if($this->input->post())
			{						
    			$this->Menu_model->addMenuPermission();
    			$this->session->set_flashdata('permission', 'Permission add successfully');
    			redirect(base_url()."menu/userpermission");
			}

			$this->load->view('menu/menu-permission',$data);
		}else{
			redirect(base_url()."login");
		}
	}
}