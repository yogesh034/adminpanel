<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		header('Cache-Control: no-cache, must-revalidate, max-age=0');
		header('Cache-Control: post-check=0, pre-check=0',false);
		header('Pragma: no-cache');
		$this->load->model('User_model');
		$this->load->model('Menu_model');
	}

	public function add($id="")
	{
		if($this->session->appraisal_logged_in)
		{		
			$isPermission = $this->Menu_model->checkPermission('employee/create');
			if(empty($isPermission))
			{
				redirect(base_url()."permissionerror"); 
			}

			$data['isPermission'] = $isPermission;
			$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
			$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
			$data['user_rolls'] = $this->User_model->getRolls();
			$data['title'] = 'Employee';
			$data['error'] = '';
			$data['employeeID'] = $id;
			if($this->input->post())
			{	
				$this->form_validation->set_rules('first_name', 'First name', 'required',
	            	array('required' => '%s is must be required.'));
				$this->form_validation->set_rules('last_name', 'Last name', 'required',
	            	array('required' => '%s is must be required.'));
				$this->form_validation->set_rules('password', 'Password', 'trim|required',
	            	array('required' => '%s is must be required.'));
	            $this->form_validation->set_rules('username', 'Username', 'trim|required',
	                array('required' => '%s is must be required.'));	            
	            $this->form_validation->set_rules('user_role_id', 'Role', 'trim|required',
	                array('required' => '%s is must be required.'));
	            $this->form_validation->set_rules('email', 'Email', 'trim|valid_email',array('valid_email' => 'Please enter a valid email address.'));

	            if ($this->form_validation->run() != FALSE){
	            	$check = $this->User_model->checkUser($this->input->post('username'),$id);
	            	if(!$check)
	            	{
	            		if($this->User_model->addUser($this->input->post(),$id))
	            		{	
	            			if($id == '')
	            			{
	            				$this->session->set_flashdata('employee', 'Employee created successfully.');
	            				redirect(base_url()."employee/create"); 
	            			}else{
	            				$this->session->set_flashdata('employee', 'Employee updated successfully.');
	            				redirect(base_url()."employee/view"); 
	            			}	            			
	            		}else{
	            			$data['error'] = var_dump($this->db->error());
	            		}  
	            	}else{
	            		$data['error'] = 'Username allready exists!';
	            	} 		            	       	
	            } 
			}else{
				if($id != '')
				{
					$data['employee_info'] = $this->User_model->getUserRow($id);		
				}
			}
			$this->load->view('employee/add-emp',$data);
		}else{
			redirect(base_url()."login");
		}
	}

	public function list()
	{
		if($this->session->appraisal_logged_in)
		{		
			$isPermission = $this->Menu_model->checkPermission('employee/view');
			if(empty($isPermission))
			{
				redirect(base_url()."permissionerror"); 
			}
			
			$data['isPermission'] = $isPermission;
			$data['menu_list']  = $this->Menu_model->getParentWithChildMenu();
			$data['acce_menu']  = $this->Menu_model->getPermissiondata($this->session->appraisal_roll_id);
			$data['employee_list']  = $this->User_model->getUsers();
			$data['title'] = 'Employee';
			$this->load->view('employee/emp-view',$data);

		}else{
			redirect(base_url()."login");
		}
	}

	public function delete()
	{
		$isdelete = $this->User_model->deleteUser($this->input->post('id'));
		if($isdelete)
		{
			//$this->session->set_flashdata('client', 'Client deleted successfully.');
			echo 1;
		}else{
			echo var_dump($this->db->error());
		}
	}
}