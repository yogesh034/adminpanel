<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model');
		$this->load->library('encryption');
		$this->encryption->initialize(
        array(
            'cipher' => 'aes-256',
            'mode' => 'ctr',
            'key' => $this->config->config['encryption_key']
    	));
	}

	public function index()
	{ 
		if($this->session->appraisal_logged_in)
		{		
			redirect(base_url().'dashboard');
		}
		else{
			$data['error'] = '';
			if($this->input->post())
			{
				$this->form_validation->set_rules('username', 'User name', 'required',
	            	array('required' => '%s is must be required.'));
	            $this->form_validation->set_rules('password', 'Password', 'required',
	                array('required' => '%s is must be required.')
	            );  

	            if ($this->form_validation->run() != FALSE)
	            {
	            	//$this->encryption->encrypt($msg);
					$password = $this->input->post('password');
					$userData = $this->Login_model->signup($this->input->post());
					if(!empty($userData))
					{
						$userData['password'] = $this->encryption->decrypt($userData['password']);
						if($userData['password'] == $password)
						{							
			            	$sessionData['appraisal_logged_in'] = TRUE;
			            	$sessionData['appraisal_name'] = trim($userData['first_name']).' '.trim($userData['last_name']);
			            	$sessionData['appraisal_email'] = trim($userData['email']);
			            	$sessionData['appraisal_id'] = trim($userData['id']);							
							$sessionData['appraisal_username'] = trim($userData['username']);
							$sessionData['appraisal_roll_id'] = trim($userData['roll_id']);
							$sessionData['appraisal_user_type'] = trim($userData['user_type']);
							$sessionData['appraisal_phone'] = trim($userData['phone']);
							$sessionData['appraisal_address'] = trim($userData['address']);
			            	$this->session->set_userdata($sessionData);
							redirect(base_url().'dashboard');
						}else{
							$data['error'] = 'password is incorrect.';
						}
					}else{
						$data['error'] = 'password or user name are incorrect.';
					}
	            }					
			}

			$data['title'] = 'Login';
			$this->load->view('login',$data);
		}
	}
	
	public function logout()
	{
		//$this->session->sess_destroy();
		$this->session->unset_userdata('appraisal_logged_in');
		$this->session->unset_userdata('appraisal_id');
		$this->session->unset_userdata('appraisal_name');		
		$this->session->unset_userdata('appraisal_email');
		$this->session->unset_userdata('appraisal_username');
		$this->session->unset_userdata('appraisal_roll_id');
		$this->session->unset_userdata('appraisal_user_type');
		$this->session->unset_userdata('appraisal_phone');
		$this->session->unset_userdata('appraisal_address');
		redirect(base_url()."login");		
	}	
}
