<?php 
class Menu_model extends CI_Model 
{
	function __construct()
	{
		parent::__construct();	
		$this->load->database();
	}	

	public function getParentMenu()
	{
		return $this->db->where('parent_id',0)->where('active','1')->order_by('menu_seq','asc')->get('menu')->result_array();
	}

	public function getParentWithChildMenu()
	{
		$parent = $this->db->where('parent_id',0)->where('active','1')->order_by('menu_seq','asc')->get('menu')->result_array();
		foreach ($parent as $key => $value) {
			$child = $this->getSubMenu($value['menu_id']);
			$parent[$key]['child'] = !empty($child) ? $child : array();
		}
		return $parent;
	}

	public function getPermissiondata($roll_id)
	{
		if($roll_id != '')
		{
			$result = $this->db->select('GROUP_CONCAT(menu_id) as menugroup')->where('user_type',$roll_id)->get('menu_permission')->row_array();
			return !empty($result['menugroup']) ? explode(',', $result['menugroup']) : array();
		}else{
			return array();
		}			
	}

	public function getSubMenu($id)
	{
		return $this->db->where('parent_id',$id)->where('active','1')->order_by('menu_seq','asc')->get('menu')->result_array();
	}

	public function checkMenu($menu_name,$id)
	{
		if($id != '')
		{
			$this->db->where('menu_id !=',$id);
		}

		$result = $this->db->where('menu_name',ucwords(trim($menu_name)))->get('menu')->num_rows();
		return $result > 0 ? true : false;
	}

	public function getMenuRow($id)
	{
		$result = $this->db->where('menu_id',$id)->get('menu')->row_array();
		return $result;
	}

	public function addMenu($data,$id='')
	{
		$post = array(
			'parent_id'=>$data['parent_id'],
			'menu_name'=>ucwords(trim($data['name'])),
			'menu_icon'=>trim($data['icon']) == '' ? 'far fa-circle' : trim($data['icon']),
			'menu_link'=>trim($data['menu_link']) == '' ? 'jacascript:void(0);' : trim($data['menu_link']),
			'menu_seq'=>trim($data['menu_seq']) == '' ? '0' : trim($data['menu_seq'])
		);

		if($id != '')
		{
			$this->db->where('menu_id',$id);
			return $this->db->update('menu',$post);
		}else{
			return $this->db->insert('menu',$post);
		}
	}	

	public function getRoll()
	{
		return $this->db->where('active','1')->order_by('name','asc')->get('role')->result_array();
	}

	public function addMenuPermission()
	{
		$oldMenu = $this->getPermissiondata($_POST['roll_id']);
		$newMenu = array();
		if(isset($_POST['parent']))
		{
		  	for ($i=0; $i < count($_POST['parent']); $i++) { 
				$post = array('menu_id'=>$_POST['parent'][$i],'menu_access'=>'','user_type'=>$_POST['roll_id']);
				$newMenu[] = $_POST['parent'][$i];
				if(!in_array($_POST['parent'][$i], $oldMenu))
				{
					$this->db->insert('menu_permission',$post);
				}				

				if(isset($_POST['parent_'.$_POST['parent'][$i]]))
				{	
					$chieldvar = $_POST['parent_'.$_POST['parent'][$i]];
					for ($j=0; $j < count($chieldvar) ; $j++) {
						 $postchield = array('menu_id'=>$chieldvar[$j],'menu_access'=>'','user_type'=>$_POST['roll_id']);
						 $newMenu[] = $chieldvar[$j];
						 if(!in_array($chieldvar[$j], $oldMenu))
						 {
							$this->db->insert('menu_permission',$postchield);
						 }						
					}
				}			
			}
			// Delete Menu
			if(!empty($oldMenu))
			{
				$deleteMenu = array();
				for ($m=0; $m < count($oldMenu); $m++) { 
					if(!in_array($oldMenu[$m], $newMenu))
					{
						$deleteMenu[] = $oldMenu[$m];
					}
				}

				if(!empty($deleteMenu))
				{
					$this->db->where('user_type',$_POST['roll_id']);
					$this->db->where_in('menu_id',$deleteMenu);
					$this->db->delete('menu_permission');
				}
			}
		}else{
			$this->db->where('user_type',$_POST['roll_id']);
			$this->db->delete('menu_permission');
		}
	}

	public function checkPermission($menu_link)
	{
		$this->db->select('m.menu_id,m.parent_id');
		$this->db->where('m.menu_link',$menu_link);
		$this->db->where('p.user_type',$this->session->appraisal_roll_id);
		$this->db->join('menu m','p.menu_id=m.menu_id');
		return $this->db->get('menu_permission p')->row_array();
	}
	
	public function deleteMenu($id)
	{
		$this->db->where('menu_id',$id);
		return $this->db->update('menu',array('active'=>0));
	}
}