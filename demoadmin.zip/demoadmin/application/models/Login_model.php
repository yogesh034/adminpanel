<?php 
class Login_model extends CI_Model 
{
	function __construct()
	{
		parent::__construct();	
		$this->load->database();
	}
	//user login
	public function signup($data)
	{
		$username = $data['username'];
		$result = $this->db->where('username',$username)->get('user')->row_array();
		return $result;
	}
}