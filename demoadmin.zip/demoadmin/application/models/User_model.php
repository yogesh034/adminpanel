<?php 
class User_model extends CI_Model 
{
	function __construct()
	{
		parent::__construct();	
		$this->load->database();
		$this->load->library('encryption');
		$this->encryption->initialize(
        array(
            'cipher' => 'aes-256',
            'mode' => 'ctr',
            'key' => $this->config->config['encryption_key']
    	));
	}

	public function getRolls()
	{
		return $this->db->where('active',1)->order_by('name','asc')->get('role')->result_array();
	}
	public function getTypes()
	{
		return $this->db->where('active',1)->order_by('name','asc')->get('user_type')->result_array();
	}
	public function checkUser($username,$id)
	{
		if($id != '')
		{
			$this->db->where('id !=',$id);
		}

		$result = $this->db->where('username',ucwords(trim($username)))->get('user')->num_rows();
		return $result > 0 ? true : false;
	}
	public function addUser($data,$id)
	{
		$passEncrypt = $this->encryption->encrypt($data['password']);
		$post = array(
			'first_name'=>ucwords(trim($data['first_name'])),
			'last_name'=>ucwords(trim($data['last_name'])),
			'email'=>trim($data['email']),
			'username'=>trim($data['username']),
			'password'=>trim($passEncrypt),
			'roll_id'=>$data['user_role_id'],
			'phone'=>trim($data['phone']),
			'created_by'=>$this->session->id,
			'active'=>isset($data['active']) ? 1 : 0
		);

		if($id != '')
		{
			$this->db->where('id',$id);
			return $this->db->update('user',$post);
		}else{
			return $this->db->insert('user',$post);
		}
	}	

	public function getUserRow($id)
	{
		return $this->db->where('id',$id)->get('user')->row_array();
	}

	public function getUsers($array = array(1,0))
	{
	  $this->db->select('u.id,u.first_name,u.last_name,u.email,u.username,u.password,u.roll_id,u.phone,u.address,u.active,r.name as rollname');
	  $this->db->join('role r','u.roll_id=r.id');
	  $this->db->where_in('u.active',$array);
	  $this->db->order_by('u.username','asc');
	  $result = $this->db->get('user u')->result_array();
	  return $result;
	}

	public function deleteUser($id)
	{
		$this->db->where('id',$id);
		return $this->db->update('user',array('active'=>2));
	}	
}