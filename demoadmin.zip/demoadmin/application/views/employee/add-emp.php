<?php $this->load->view('include/headpart'); ?>
<body class="hold-transition sidebar-mini layout-fixed text-sm sidebar-collapse">
<div class="wrapper">
  <!-- Navbar -->
 <?php $this->load->view('include/navbar'); ?>
  <!-- /.navbar -->
  <!-- Main Sidebar Container -->     
    <?php $this->load->view('include/sidebar-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper content_background">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?=$title?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?=$title?></a></li>
              <li class="breadcrumb-item active"><?=$employeeID == '' ? 'Add' : 'Update'?> <?=$title?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">          
          <!-- /.col (left) -->
          <div class="col-md-12">            
            <div class="card card-default">
              <div class="card-header bg-purple">
                <h3 class="card-title"><?=$employeeID == '' ? 'Add' : 'Update'?> <?=$title?> Detail</h3>
              </div>
              <form method="post" action="">
                <div class="card-body">                  
                  <div class="form-group"> 
                   <div class="row">
                      <?php 
                        if(isset($employee_info))
                          {
                            $first_name = $employee_info['first_name'];
                          }else{
                            $first_name = set_value('first_name');
                          }
                        ?>                   
                        <div class="col-md-4">
                          <label>Firsr Name <code>* <?=strip_tags(form_error('first_name'))?></code></label>
                          <input type="text" name="first_name" value="<?=$first_name?>" class="form-control" placeholder="First Name">
                        </div> 

                        <?php 
                        if(isset($employee_info))
                          {
                            $last_name = $employee_info['last_name'];
                          }else{
                            $last_name = set_value('last_name');
                          }
                        ?>                
                        <div class="col-md-4">
                          <label>Last Name <code>* <?=strip_tags(form_error('last_name'))?></code></label>
                          <input type="text" name="last_name" value="<?=$last_name?>" class="form-control" placeholder="Last Name">
                        </div>                                                                   
                      </div>
                   </div>                      

                  <div class="form-group">  
                    <div class="row">
                    	<?php 
                        if(isset($employee_info))
                          {
                            $phone = $employee_info['phone'];
                          }else{
                            $phone = set_value('phone');
                          }
                        ?>                   
                        <div class="col-md-4">
                          <label>Mobile No.</label>
                          <input type="text" name="phone" value="<?=$phone?>" class="form-control" placeholder="1234567890">
                        </div> 

                    	<?php 
                        if(isset($employee_info))
                          {
                            $email = $employee_info['email'];
                          }else{
                            $email = set_value('email');
                          }
                        ?>                
                        <div class="col-md-4">
                          <label>Email <code><?=strip_tags(form_error('email'))?></code></label>
                          <input type="text" name="email" value="<?=$email?>" class="form-control" placeholder="test@iservegroup.net">
                        </div>                                    
                    </div>                    
                  </div> 
                  <div class="form-group">  
                    <div class="row">
                    	<div class="col-md-4">
                    		<label>User Type <code>* <?=strip_tags(form_error('user_type_id'))?></code></label>
                    		<select name="user_type_id" class="form-control">
		                      <option value="">Select Type</option>
		                      <?php
		                       foreach ($user_types as $key => $value) {
	                          if(isset($employee_info))
	                          {
	                            $selectedtype = $employee_info['user_type'] == $value['id'] ? 'selected' : '';
	                          }else{
	                            $selectedtype = set_value('user_type_id') == $value['id'] ? 'selected' : '';
	                          }                          
		                       	echo "<option $selectedtype value='".$value['id']."'>".$value['name']."</option>";
		                       } 
		                      ?>
	                        </select>
                    	</div>

                    	<div class="col-md-4">
                    		<label>User Role <code>* <?=strip_tags(form_error('user_role_id'))?></code></label>
                    		<select name="user_role_id" class="form-control">
		                      <option value="">Select Role</option>
		                      <?php
		                       foreach ($user_rolls as $keyroll => $roleval) {
	                          if(isset($employee_info))
	                          {
	                            $selectedtype = $employee_info['roll_id'] == $roleval['id'] ? 'selected' : '';
	                          }else{
	                            $selectedtype = set_value('user_role_id') == $roleval['id'] ? 'selected' : '';
	                          }                          
		                       	echo "<option $selectedtype value='".$roleval['id']."'>".$roleval['name']."</option>";
		                       } 
		                      ?>
	                        </select>
                    	</div>
	                  		
                  	</div>
                  </div>
                  <div class="form-group">
                  	<div class="row">
                  		<?php 
                        if(isset($employee_info))
                          {
                            $username = $employee_info['username'];
                          }else{
                            $username = set_value('username');
                          }
                        ?>  

                        <div class="col-md-4">
                          <label>Username <code>* <?=strip_tags(form_error('username'))?><?=$usererror?></code></label>
                          <input type="text" name="username" value="<?=$username?>" class="form-control" placeholder="User Name">
                        </div>

                        <?php 
                        if(isset($employee_info))
                          {                          	
                            $password = trim($this->encryption->decrypt($employee_info['password']));
                          }else{
                            $password = set_value('password');
                          }
                        ?>                
                        <div class="col-md-4">
                          <label>Password <code>* <?=strip_tags(form_error('password'))?></code></label>
                          <input type="password" name="password" value="<?=$password?>" class="form-control" placeholder="Password">
                        </div>          
                  	</div>
                  </div>

                  <div class="form-group">
                   <div class="row">
                      <?php 
                        if(isset($employee_info))
                          {
                            $address = $employee_info['address'];
                          }else{
                            $address = set_value('address');
                          }
                        ?>                  
                        <div class="col-md-5">
                          <label>Address</label>
                          <textarea class="form-control" name="address" rows="3" placeholder="Enter ..."><?=$address?></textarea>
                        </div>                    
                      </div>
                   </div> 

                   <div class="form-group">
                   <div class="row">
                   		<?php 
	                    if(isset($employee_info))
	                      {
	                        $checked = $employee_info['active'] == 1 ? 'checked' : '';
	                      }else{
	                        $checked = set_value('active') == 1 ? 'checked' : '';
	                      }
	                    ?>                                    
		                    <div class="col-4">                                    	                  
		                      <div class="icheck-success d-inline">                         
		                          <input type="checkbox" <?=$checked?> name="active" value="1" id="1"> 
		                          <label for="1">Is Active</label>                    
		                     </div>                      
		                    </div>
                   	</div>
                   </div>                     
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn bg-purple btn-default">Submit</button> 
                  <?php 
                  if(isset($employee_info)){
                    echo '<a class="btn btn-danger" href="javascript:history.back()">Go Back</a>';
                  }                  
                  ?>        
                </div>
              <!-- /.card-body -->
              </form>                
            </div>
          </div>
          <!-- /.col (right) -->
        </div>
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('include/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/script'); ?>
<!-- Page specific script -->
<?php 
if($this->session->flashdata('employee'))
{ 
  echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 1500
    });
    Toast.fire({
        icon: 'success',
        title: '&nbsp;&nbsp;".$this->session->flashdata('employee')."'
      })
});
</script>";
}

if($error != '')
{ 
  echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 1500
    });
    Toast.fire({
        icon: 'error',
        title: '&nbsp;&nbsp;".$error."'
      })
});
</script>";
}
?>
<?php //$this->load->view('scripts/demo-js'); ?>
</body>
</html>