 <nav class="<?=NAV_CLASS?>">
    	<!-- Left navbar links -->
	    <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
	      </li>            
	    </ul>
    	<!-- Right navbar links -->
	    <ul class="navbar-nav ml-auto">     
	      <!-- Notifications Dropdown Menu -->
	      <!-- <li class="nav-item">
	        <a class="nav-link" href="javascript:void(0);">
	          <i class="fas fa-circle text-success"></i>
	           Welcome : <?=ucwords($this->session->appraisal_name)?> </a>        
	      </li> -->       
	      <li class="nav-item">
	        <a style="" class="nav-link" href="<?=base_url()?>logout">
	          <i class="fas fa-sign-out-alt"></i> Sign out          
	        </a>        
	      </li>   
	    </ul>
  </nav>