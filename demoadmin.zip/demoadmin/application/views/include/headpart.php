<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?=$title?></title>
  <?php $this->load->view('include/css'); ?>
  <style type="text/css">
  	.content_background {
  		/*background-color: #b5b7b9;*/
  	}
  </style>
</head>