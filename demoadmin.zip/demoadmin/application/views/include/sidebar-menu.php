  <?php 
  $activeMenuId = !empty($isPermission) ? $isPermission['menu_id'] : '';
  $activeMenuParentId = !empty($isPermission) ? $isPermission['parent_id'] : '';
  ?>
  <aside class="<?=ASIDE_CLASS?>">	
 	 <!-- Brand Logo -->
    <a href="<?=base_url()?>" class="<?=BRAND_LOGO_CLASS?>">
      <img src="<?=base_url()?>assets/dist/img/logo.jpeg" alt="Iservegroup Logo" class="brand-image img-rounded elevation-3" style="opacity: .8; background-color: white;">
      <span class="brand-text font-weight-light">Dashboard</span>
    </a>
    <!-- Sidebar -->
 	<div class="sidebar"> 		
      <!-- Sidebar Menu -->
      <nav class="mt-2">
	        <ul class="<?=NAV_UL_CLASS?>" data-widget="treeview" role="menu" data-accordion="false">
	          <!-- Add icons to the links using the .nav-icon class
	               with font-awesome or any other icon font library -->
	        <?php 
	        foreach ($menu_list as $menuindex => $menuitem) {
	        if(in_array($menuitem['menu_id'], $acce_menu))
	        {	        
	        	$url = $menuitem['menu_link'] == 'jacascript:void(0);' ? '#' : base_url().$menuitem['menu_link'];
	        	$menuOpen = $activeMenuParentId == $menuitem['menu_id'] ? 'menu-open' : '';	            
	        ?>
	        	<!-- MAIN MENU -->
		        <li class="nav-item <?=$menuOpen?>">
		        	<?php 
		        	if($activeMenuId==$menuitem['menu_id'] || $activeMenuParentId==$menuitem['menu_id'])
		        	{
		        		echo '<a href="'.$url.'" class="nav-link active">';
		        	}else{
		        		echo '<a href="'.$url.'" class="nav-link">';
		        	}
		        	?>		            
		              <i class="<?=$menuitem['menu_icon']?> nav-icon"></i>
		              <p>
		                <?=$menuitem['menu_name']?>	
		                <?php if(!empty($menuitem['child'])) { echo '<i class="right fas fa-angle-left"></i>'; } ?>                              
		              </p>
		            </a>
		        <!-- SUB MENU -->
	            <?php 
	            	if(!empty($menuitem['child']))
	            	{
	            		echo '<ul class="nav nav-treeview">';
	            		foreach ($menuitem['child'] as $child_key => $chield_value) {
	            		if(in_array($chield_value['menu_id'], $acce_menu))
	            		{ 
	            			$urlChild = $chield_value['menu_link'] == 'jacascript:void(0);' ? '#' : base_url().$chield_value['menu_link'];
	            			$chieldActive = $activeMenuId==$chield_value['menu_id'] ? 'active' : '';
	            		?>
	            			<li class="nav-item">
				                <a href="<?=$urlChild?>" class="nav-link <?=$chieldActive?>">
				                  <i class="nav-icon <?=$chield_value['menu_icon']?>"></i>
				                  <p><?=$chield_value['menu_name']?></p>
				                </a>
			            	</li>
	            		<?php }
	            		}
	            		echo '</ul>';
	            	}
	            ?>
		        </li> 
	        <?php } } ?>       
	        </ul>  
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>