<?php $this->load->view('include/headpart'); ?>
<body class="<?=BODY_CLASS?>">
<div class="wrapper">
  <!-- Navbar -->
 <?php $this->load->view('include/navbar'); ?>
  <!-- /.navbar -->
  <!-- Main Sidebar Container -->     
    <?php $this->load->view('include/sidebar-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper content_background">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <!-- <h1><?=$title?></h1> -->
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
             <!--  <li class="breadcrumb-item"><a href="#"><?=$title?></a></li> -->
              <!-- <li class="breadcrumb-item active"><?=$title?></li> -->
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">          
          <!-- /.col (left) -->
          <div class="col-md-12">            
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><?=$title?></h3>
              </div>              
                   <div style="min-height: 550px;" class="error-page">
        			<h2 class="headline text-yellow"> <?=$title?></h2>
				        <div class="error-content">
				          <h3><i class="fa fa-warning text-yellow"></i> Oops! Permission denied.</h3>
				          <p>
				            We could not find the page you were looking for.
				            Meanwhile, you may <a href="<?=base_url()?>">return to home.</a>
				          </p>          
				        </div>
			        <!-- /.error-content -->
			       </div>         
            </div>
          </div>
          <!-- /.col (right) -->
        </div>
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('include/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/script'); ?>
<!-- Page specific script -->
<?php $this->load->view('scripts/demo-js'); ?>
</body>
</html>