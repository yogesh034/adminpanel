<?php $this->load->view('include/headpart'); ?>
<body class="<?=BODY_CLASS?>">
<div class="wrapper">
  <!-- Navbar -->
 <?php $this->load->view('include/navbar'); ?>
  <!-- /.navbar -->
  <!-- Main Sidebar Container -->     
    <?php $this->load->view('include/sidebar-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper content_background">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?=$title?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?=$title?></a></li>
              <li class="breadcrumb-item active">Add <?=$title?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">          
          <!-- /.col (left) -->
          <div class="col-md-12">            
            <div class="card card-secondary card-outline">
              <div class="card-header">
                <h3 class="card-title">Add <?=$title?></h3>
              </div>              
              <form name="menu_form" method="post" action="">                
                <div class="card-body">
                  <div class="form-group">                  
                    <div class="col-4">
                      <label>User Roll</label>
                      <select name="roll_id" onchange="function_name(this.value);" class="form-control">
	                      <option value="">Select User Roll</option>
	                      <?php
	                       foreach ($user_roll as $key => $value) {
                          $selected = $roll_id == $value['id'] ? 'selected' : '';
	                       	echo "<option $selected value='".$value['id']."'>".$value['name']."</option>";
	                       } 
	                      ?>
                      </select>
                    </div>                    
                  </div>
                  <div class="form-group">
                    <label><code><?=strip_tags(form_error('parent'))?></code></label>
                    <div class="row">                      
                    <?php 
                    foreach ($menu_tree as $index => $tree) {
                    $Pchecked =  in_array($tree['menu_id'], $menu_group) ? 'checked' : '';
                    $isDisable = in_array($tree['menu_id'], $menu_group) ? '' : 'disabled';
                    $chieldclass = 'parent__'.$tree['menu_id'];                    
                    echo '<div class="col-md-4 callout"><ol style="list-style-type: none;">';
                    ?>
                      <li>
                        <div class="icheck-success d-inline">
                          <input type="checkbox" <?=$Pchecked?> onclick="checkChield(this.checked,<?=$tree['menu_id']?>);" name="parent[]" value="<?=$tree['menu_id']?>" id="<?=$tree['menu_id']?>">&nbsp;&nbsp;
                          <label for="<?=$tree['menu_id']?>"><?=$tree['menu_name']?></label>
                        </div>
                        <?php 
                          if(!empty($tree['child']))
                          {
                            echo "<ol>";
                            foreach ($tree['child'] as $child => $ctree) { 
                              $chield_value = 'parent_'.$tree['menu_id'];
                              $Cchecked =  in_array($ctree['menu_id'], $menu_group) ? 'checked' : '';
                            ?>
                                <li>
                                  <div class="icheck-success d-inline">
                                    <input type="checkbox" <?=$Cchecked?> <?=$isDisable?> class="parent<?=$tree['menu_id']?>" name="<?=$chield_value?>[]" value="<?=$ctree['menu_id']?>" id="<?=$ctree['menu_id']?>">&nbsp;&nbsp;
                                    <label for="<?=$ctree['menu_id']?>"><?=$ctree['menu_name']?></label>
                                  </div>
                                </li>
                            <?php }
                            echo "</ol>";
                          }
                        ?>
                      </li>
                    <?php echo '</ol> </div> '; }  ?>   
                    </div>
                  </div>                                                   
                </div>
                <div class="card-footer">
                  <button type="submit" <?php echo $roll_id != '' ? '' : 'style="display: none;"' ?> class="btn btn-secondary">Submit</button>      
                </div>
              <!-- /.card-body -->
              </form>                
            </div>
          </div>
          <!-- /.col (right) -->
        </div>
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('include/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/script'); ?>
<!-- Page specific script -->
<?php $this->load->view('scripts/demo-js'); ?>
<?php 
if($this->session->flashdata('permission'))
{ 
	echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 5000
    });
    Toast.fire({
        icon: 'success',
        title: '".$this->session->flashdata('permission')."'
      })
});
</script>";
}

if($error != '')
{ 
	echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 5000
    });
    Toast.fire({
        icon: 'error',
        title: '".$error."'
      })
});
</script>";
}
?>
<script type="text/javascript">
  function function_name(id) {
    window.location.href = "<?=base_url()?>menu/permission/"+id;
  }
  function checkChield(status,id) {
    if(status == true)
    {
      $(".parent"+id).removeAttr('disabled', 'disabled');
      $(".parent"+id).prop('checked', true);
    }else{
      $(".parent"+id).attr('disabled', 'disabled');
      $(".parent"+id).prop('checked', false);
    }
  }
</script>
</body>
</html>