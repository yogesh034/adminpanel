<?php $this->load->view('include/headpart'); ?>
<body class="<?=BODY_CLASS?>">
<div class="wrapper">
  <!-- Navbar -->
 <?php $this->load->view('include/navbar'); ?>
  <!-- /.navbar -->
  <!-- Main Sidebar Container -->     
    <?php $this->load->view('include/sidebar-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper content_background">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?=$title?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?=$title?></a></li>
              <li class="breadcrumb-item active"><?=$menuID == '' ? 'Add' : 'Update'?> <?=$title?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">          
          <!-- /.col (left) -->
          <div class="col-md-12">            
            <div class="card card-secondary card-outline">
              <div class="card-header">
                <h3 class="card-title"><?=$menuID == '' ? 'Add' : 'Update'?> <?=$title?> Detail</h3>
              </div>              
              <form name="menu_form" method="post" action="">
                <div class="card-body">
                  <div class="form-group">                  
                    <div class="col-4">
                      <label>Parent Menu</label>
                      <select name="parent_id" class="form-control">
	                      <option value="0">Select Parent Menu - Default is Parent</option>
	                      <?php
	                       foreach ($all_parent as $key => $value) {
                          if(isset($menu_imfo))
                          {
                            $selectedparent = $menu_imfo['parent_id'] == $value['menu_id'] ? 'selected' : '';
                          }else{
                            $selectedparent = set_value('parent_id') == $value['menu_id'] ? 'selected' : '';
                          }                          
	                       	echo "<option $selectedparent value='".$value['menu_id']."'>".$value['menu_name']."</option>";
	                       } 
	                      ?>
                      </select>
                    </div>                    
                  </div>
                  <div class="form-group">   
                    <?php 
                    if(isset($menu_imfo))
                      {
                        $name = $menu_imfo['menu_name'];
                      }else{
                        $name = set_value('name');
                      }
                    ?>                 
                    <div class="col-4">
                      <label>Menu Name <code>* <?=strip_tags(form_error('name'))?></code></label>
                      <input type="text" name="name" value="<?=$name?>" class="form-control" placeholder="Menu Name">
                    </div>                    
                  </div>                
                  <div class="form-group">  
                    <?php 
                    if(isset($menu_imfo))
                      {
                        $icon = $menu_imfo['menu_icon'];
                      }else{
                        $icon = set_value('icon');
                      }
                    ?>                
                    <div class="col-4">
                      <label>Menu Icon</label>
                      <input type="text" name="icon" value="<?=$icon?>" class="form-control" placeholder="fas fa-tachometer-alt">
                    </div>                    
                  </div>
                  <div class="form-group">   
                    <?php 
                    if(isset($menu_imfo))
                      {
                        $menu_link = $menu_imfo['menu_link'];
                      }else{
                        $menu_link = set_value('menu_link');
                      }
                    ?>                 
                    <div class="col-4">
                      <label>Menu Link</label>
                      <input type="text" name="menu_link" value="<?=$menu_link?>" class="form-control" placeholder="dashboard">
                    </div>                   
                  </div>
                  <div class="form-group">  
                    <?php 
                    if(isset($menu_imfo))
                      {
                        $menu_seq = $menu_imfo['menu_seq'];
                      }else{
                        $menu_seq = set_value('menu_seq');
                      }
                    ?>                   
                    <div class="col-2">
                      <label>Menu Sequence</label>
                      <input type="number" name="menu_seq" min="0" max="100" value="<?=$menu_seq?>" class="form-control" placeholder="0">
                    </div>                   
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-secondary">Submit</button> 
                  <?php 
                  if(isset($menu_imfo)){
                    echo '<a class="btn btn-danger" href="javascript:history.back()">Go Back</a>';
                  }                  
                  ?>  
                </div>
              <!-- /.card-body -->
              </form>                
            </div>
          </div>
          <!-- /.col (right) -->
        </div>
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('include/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/script'); ?>
<!-- Page specific script -->
<?php $this->load->view('scripts/demo-js'); ?>
<?php 
if($this->session->flashdata('menu'))
{ 
	echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 1500
    });
    Toast.fire({
        icon: 'success',
        title: '&nbsp;&nbsp;".$this->session->flashdata('menu')."'
      })
});
</script>";
}

if($error != '')
{ 
	echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 1500
    });
    Toast.fire({
        icon: 'error',
        title: '&nbsp;&nbsp;".$error."'
      })
});
</script>";
}
?>
</body>
</html>