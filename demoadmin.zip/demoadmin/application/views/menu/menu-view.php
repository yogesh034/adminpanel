<?php $this->load->view('include/headpart'); ?>
<body class="<?=BODY_CLASS?>">
<div class="wrapper">
  <!-- Navbar -->
 <?php $this->load->view('include/navbar'); ?>
  <!-- /.navbar -->
  <!-- Main Sidebar Container -->     
    <?php $this->load->view('include/sidebar-menu'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper content_background">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?=$title?> View</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?=$title?></a></li>
              <li class="breadcrumb-item active"><?=$title?> View</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">          
          <!-- /.col (left) -->
          <div class="col-md-12">            
            <div class="card card-secondary card-outline">
              <div class="card-header">
                <h3 class="card-title"><?=$title?> View</h3>
              </div> 
              <div class="card-body">             
                <table id="menu_view" class="table table-bordered table-striped table-sm">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Menu Name</th>
                    <th>Parent Name</th>
                    <th>Menu Link</th>
                    <th width="10%">Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                  $i=1;
                  foreach ($menu_list as $key => $value) { ?>
                  	<tr>
	                    <td><?=$i?></td>
	                    <td><?=$value['menu_name']?></td>
	                    <td><?=$value['menu_name']?></td>
	                    <td><?=$value['menu_link']?></td>
	                    <td>
	                    	<a class="btn btn-outline-secondary btn-xs" href="<?=base_url()?>menu/edit/<?=$value['menu_id']?>">
		                    	<i class="fas fa-edit"></i>
      	        				</a>
      	        				&nbsp;
      	        				<a class="btn btn-outline-danger btn-xs" onclick="showpopup(<?=$value['menu_id']?>)" href="javascript:void(0);">
      			                    	<i class="fas fa-trash-alt"></i>
      		        				</a>
      	        			</td>
                    </tr>   
                  <?php 
                  if(!empty($value['child']))
                  {                  	
                  	foreach ($value['child'] as $childkey => $childvalue) { 
                      $i++;
                    ?>
                  		<tr>
		                    <td><?=$i?></td>
		                    <td><?=$childvalue['menu_name']?></td>
		                    <td><?=$value['menu_name']?></td>
		                    <td><?=$childvalue['menu_link']?></td>
		                    <td>
		                    	<a class="btn btn-outline-secondary btn-xs" href="<?=base_url()?>menu/edit/<?=$childvalue['menu_id']?>">
		                    		<i class="fas fa-edit"></i>
      	        					</a>
      	        					&nbsp;
      		        				<a class="btn btn-outline-danger btn-xs" onclick="showpopup(<?=$childvalue['menu_id']?>)" href="javascript:void(0);">
      			                    	<i class="fas fa-trash-alt"></i>
      		        				</a>
    	        				</td>
	                    </tr> 
                    <?php } 
                  }   $i++;
                    }
                  ?>                                 
                  </tbody>
                </table>
               </div>
            </div>
          </div>
          <!-- /.col (right) -->
        </div>
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- Modal -->
    <div class="modal fade" id="modal-warning" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content bg-warning">
            <div class="modal-header">
              <h4 class="modal-title"><i class="fas fa-exclamation-triangle"></i> Warning</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
               <input type="hidden" id="menu_item_id" value="">
              <p>Are you sure to delete this menu?</p>
            </div>
            <div class="modal-footer justify-content-between">              
              <button type="button" onclick="deletemenu();" class="btn btn-success">Yes</button>
              <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /Modal -->
  </div>
  <!-- /.content-wrapper -->
  <?php $this->load->view('include/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('include/script'); ?>
<!-- Page specific script -->
<?php 
if($this->session->flashdata('menu'))
{ 
	echo "<script type='text/javascript'>
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 1500
    });
    Toast.fire({
        icon: 'success',
        title: '&nbsp;&nbsp;".$this->session->flashdata('menu')."'
      })
});
</script>";
} ?>

<script type="text/javascript"> 
$(function() {
    var Toast = Swal.mixin({
      toast: true,
      position: 'bottomRight',
      showConfirmButton: false,
      timer: 1500
    });    
});
 
  $(function () {    
    $("#menu_view").DataTable({
      "aLengthMenu": [[5, 10, 15, 25, 50, 100 , -1], [5, 10, 15, 25, 50, 100, "All"]],
      "iDisplayLength" : 50,
      "responsive": true, "lengthChange": false, "autoWidth": false,
      // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#menu_view_wrapper .col-md-6:eq(0)');
  });

  function showpopup(id) {
  	$("#menu_item_id").val(id);
  	$("#modal-warning").modal("show");
  }

  function deletemenu() {
  	var id = $("#menu_item_id").val();			 
	  $.ajax({ 
	      type: "POST", 
	      url: "<?=base_url()?>menu/delete",
	      data: {
	        "id": id 
	      }, 
	      cache: false, 
	      success: function (data) { 			
			if(data == 1)
			{
				window.location.href = "<?=base_url()?>menu/view";
			}else{
				Toast.fire({
			        icon: 'error',
			        title: '&nbsp;&nbsp;'+data
			    })

			    $("#modal-warning").modal("hide");				
			}
	      }
	});
  }
</script>
<?php $this->load->view('scripts/demo-js'); ?>
</body>
</html>