<?php
if(!function_exists('dataencrypt'))
{
	function dataencrypt($string)
	{   
		$CI =& get_instance();
		$CI->load->library('encrypt');
		return $CI->encrypt->encode($string);
	}
}

if(!function_exists('datadecrypt'))
{
	function datadecrypt($string)
	{
		$CI =& get_instance();
		$CI->load->library('encrypt');
		return $CI->encrypt->decode($string);
	}
}

if(!function_exists('dataverify'))
{
	function dataverify($encrypt,$string)
	{   
		$CI =& get_instance();
		$CI->load->library('encrypt');
		$verify = $CI->encrypt->decode($encrypt);
		return $verify == $string ? 1 : 0;
	}
}